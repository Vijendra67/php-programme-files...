# Voting-System
Online Voting System Application

Steps for Publishing the website on the local host.
1.	Downlaod and install xampp server.
2.	Extract the zip file named 'voting' in the htdocs folder.
3.	Run xampp server and create a database named 'voting_system'.
4.	Import the 'voting_system.sql' file that is present inside the 'voting' folder
5.	Write this 'localhost/voting' in the url bar.


Admin Login:
Username : lokendra@admin.com
Password : Admin

Or You may change admin details in PHPMyadmin database.


This is Front Page.
![Screenshot (6)](https://user-images.githubusercontent.com/82303189/118472816-e7c4b280-b726-11eb-8be8-a3d81b313586.png)

This is Result Page.
![Screenshot (7)](https://user-images.githubusercontent.com/82303189/118472831-ec896680-b726-11eb-99b4-33a49f5a4803.png)

This is Admin Page.
![Screenshot (8)](https://user-images.githubusercontent.com/82303189/118472843-f01ced80-b726-11eb-8858-4556563de250.png)

This is Login or Voting Page.
![Screenshot (9)](https://user-images.githubusercontent.com/82303189/118472847-f14e1a80-b726-11eb-8841-24bd63cda87e.png)

Admin have all the access like
1. Declared and Undeclared Result.
2. Add New Admin.
3. Edit and Delete Users Information.
4. Add Participants.
5. Edit and Delete Participants.
6. Nominee Details. etc
